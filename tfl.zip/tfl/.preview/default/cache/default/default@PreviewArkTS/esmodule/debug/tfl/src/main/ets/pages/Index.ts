if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface Index_Params {
    message?: string;
    currentTabIndex?: number;
    displayedJobs?: JobData[];
    showDialog?: boolean;
    tabs?: string[];
    jobList?: JobData[];
}
interface JobData {
    id: number;
    title: string;
    salary: string; //工资
    company: string; //贵司信息
    require: string; //要求
    contact: string; //联系人
    location: string; //地点
}
class Index extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__message = new ObservedPropertySimplePU('Hello World', this, "message");
        this.__currentTabIndex = new ObservedPropertySimplePU(0, this, "currentTabIndex");
        this.__displayedJobs = new ObservedPropertyObjectPU([], this, "displayedJobs");
        this.__showDialog = new ObservedPropertySimplePU(false, this, "showDialog");
        this.tabs = ['推荐', '附近', '最新'];
        this.jobList = [
            {
                id: 1,
                title: "鸿蒙开发工程师",
                salary: "55-75K·16薪",
                company: "小红书",
                require: "3-5年，本科、软件开发、前端技术",
                contact: "李利",
                location: " 朝阳区 亚运村",
            },
            {
                id: 2,
                title: "鸿蒙开发工程师(J12447)",
                salary: "25-35K·14薪",
                company: "点点互动",
                require: "3-5年、大专、问题排查、跨平台开发",
                contact: "赵娜",
                location: "海淀区 中关村",
            },
            {
                id: 3,
                title: "居家鸿蒙工程师",
                salary: "500–1500元/天",
                company: "韶天科技",
                require: "5-10年、Java、MySQL",
                contact: "钱三",
                location: "太原 万柏林区 下元"
            },
            {
                id: 4,
                title: "鸿蒙应用开发工程师",
                salary: "20–40K",
                company: "微博",
                require: "5-10年、本科、技术栈、沟通能力",
                contact: "孙可",
                location: "海淀区 西北旺"
            }
        ];
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: Index_Params) {
        if (params.message !== undefined) {
            this.message = params.message;
        }
        if (params.currentTabIndex !== undefined) {
            this.currentTabIndex = params.currentTabIndex;
        }
        if (params.displayedJobs !== undefined) {
            this.displayedJobs = params.displayedJobs;
        }
        if (params.showDialog !== undefined) {
            this.showDialog = params.showDialog;
        }
        if (params.tabs !== undefined) {
            this.tabs = params.tabs;
        }
        if (params.jobList !== undefined) {
            this.jobList = params.jobList;
        }
    }
    updateStateVars(params: Index_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__message.purgeDependencyOnElmtId(rmElmtId);
        this.__currentTabIndex.purgeDependencyOnElmtId(rmElmtId);
        this.__displayedJobs.purgeDependencyOnElmtId(rmElmtId);
        this.__showDialog.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__message.aboutToBeDeleted();
        this.__currentTabIndex.aboutToBeDeleted();
        this.__displayedJobs.aboutToBeDeleted();
        this.__showDialog.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __message: ObservedPropertySimplePU<string>;
    get message() {
        return this.__message.get();
    }
    set message(newValue: string) {
        this.__message.set(newValue);
    }
    private __currentTabIndex: ObservedPropertySimplePU<number>; // 默认选中"推荐"标签
    get currentTabIndex() {
        return this.__currentTabIndex.get();
    }
    set currentTabIndex(newValue: number) {
        this.__currentTabIndex.set(newValue);
    }
    private __displayedJobs: ObservedPropertyObjectPU<JobData[]>; // 当前显示的职位列表
    get displayedJobs() {
        return this.__displayedJobs.get();
    }
    set displayedJobs(newValue: JobData[]) {
        this.__displayedJobs.set(newValue);
    }
    private __showDialog: ObservedPropertySimplePU<boolean>; // 控制提示框显示状态
    get showDialog() {
        return this.__showDialog.get();
    }
    set showDialog(newValue: boolean) {
        this.__showDialog.set(newValue);
    }
    // 职位卡片构建器
    buildJobCard(job: JobData, parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 5 });
            Column.debugLine("tfl/src/main/ets/pages/Index.ets(22:5)", "tfl");
            Column.margin({ bottom: 10 });
            Column.borderWidth(1);
            Column.borderColor('#ff797676');
            Column.borderRadius(8);
            Column.width('95%');
            Column.height(100);
            Column.onClick(() => {
                this.showDialog = true; // 显示提示框
            });
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 职位、薪资
            Row.create();
            Row.debugLine("tfl/src/main/ets/pages/Index.ets(24:7)", "tfl");
            // 职位、薪资
            Row.backgroundColor(Color.White);
            // 职位、薪资
            Row.width('100%');
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(job.title);
            Text.debugLine("tfl/src/main/ets/pages/Index.ets(25:9)", "tfl");
            Text.fontSize(16);
            Text.fontColor({ "id": 125831025, "type": 10001, params: [], "bundleName": "com.0408.myapplication", "moduleName": "tfl" });
            Text.margin({ left: 10, bottom: 5, right: 20, top: 5 });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(job.salary);
            Text.debugLine("tfl/src/main/ets/pages/Index.ets(29:9)", "tfl");
            Text.fontSize(16);
            Text.fontColor('#ff43b5c4');
            Text.height(10);
            Text.margin({ right: 20, bottom: 5 });
        }, Text);
        Text.pop();
        // 职位、薪资
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 公司
            Text.create(job.company);
            Text.debugLine("tfl/src/main/ets/pages/Index.ets(39:7)", "tfl");
            // 公司
            Text.fontSize(14);
            // 公司
            Text.fontColor('#666666');
            // 公司
            Text.margin({ left: 15, bottom: 5 });
            // 公司
            Text.backgroundColor(Color.White);
            // 公司
            Text.width('100%');
            // 公司
            Text.height(15);
        }, Text);
        // 公司
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 要求
            Text.create(job.require);
            Text.debugLine("tfl/src/main/ets/pages/Index.ets(48:7)", "tfl");
            // 要求
            Text.fontSize(12);
            // 要求
            Text.margin({ left: 5 });
            // 要求
            Text.fontColor('#999999');
            // 要求
            Text.backgroundColor(Color.White);
            // 要求
            Text.width('100%');
        }, Text);
        // 要求
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 联系人、地点
            Row.create();
            Row.debugLine("tfl/src/main/ets/pages/Index.ets(56:7)", "tfl");
            // 联系人、地点
            Row.backgroundColor(Color.White);
            // 联系人、地点
            Row.margin({ bottom: 2 });
            // 联系人、地点
            Row.width('100%');
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": -1, "type": -1, params: [`app.media.tx`], "bundleName": "com.0408.myapplication", "moduleName": "tfl" });
            Image.debugLine("tfl/src/main/ets/pages/Index.ets(57:9)", "tfl");
            Image.width(20);
            Image.height(20);
            Image.margin({ left: 5, right: 5 });
        }, Image);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(job.contact);
            Text.debugLine("tfl/src/main/ets/pages/Index.ets(61:9)", "tfl");
            Text.fontSize(12);
            Text.margin({ left: 15 });
            Text.fontColor('#666666');
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(job.location);
            Text.debugLine("tfl/src/main/ets/pages/Index.ets(65:9)", "tfl");
            Text.fontSize(12);
            Text.fontColor('#999999');
            Text.margin({ left: 50 });
        }, Text);
        Text.pop();
        // 联系人、地点
        Row.pop();
        Column.pop();
    }
    // 自定义提示框组件
    customDialog(parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 半透明背景
            Column.create();
            Column.debugLine("tfl/src/main/ets/pages/Index.ets(90:5)", "tfl");
            // 半透明背景
            Column.width('100%');
            // 半透明背景
            Column.height('100%');
            // 半透明背景
            Column.backgroundColor('#4dd7d5d5');
            // 半透明背景
            Column.opacity(0.5);
            // 半透明背景
            Column.onClick(() => {
                this.showDialog = false; // 点击背景关闭提示框
            });
        }, Column);
        // 半透明背景
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 提示框内容
            Column.create();
            Column.debugLine("tfl/src/main/ets/pages/Index.ets(100:5)", "tfl");
            // 提示框内容
            Column.width(250);
            // 提示框内容
            Column.height(150);
            // 提示框内容
            Column.backgroundColor(Color.White);
            // 提示框内容
            Column.borderRadius(10);
            // 提示框内容
            Column.shadow({ radius: 10, color: '#000000', offsetX: 0, offsetY: 0 });
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('查看详情');
            Text.debugLine("tfl/src/main/ets/pages/Index.ets(101:7)", "tfl");
            Text.fontSize(20);
            Text.fontColor(Color.Black);
            Text.margin({ top: 50 });
        }, Text);
        Text.pop();
        // 提示框内容
        Column.pop();
    }
    private tabs: string[];
    private jobList: JobData[];
    aboutToAppear() {
        // 初始化显示的职位列表
        this.updateDisplayedJobs();
    }
    // 根据选中的标签更新显示的职位列表
    updateDisplayedJobs() {
        switch (this.currentTabIndex) {
            case 0: // 推荐
                this.displayedJobs = this.jobList;
                break;
            case 1: // 附近
                this.displayedJobs = this.jobList.slice(1, 4);
                break;
            case 2: // 最新
                this.displayedJobs = this.jobList.slice(1);
                break;
        }
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Stack.create();
            Stack.debugLine("tfl/src/main/ets/pages/Index.ets(176:5)", "tfl");
            Stack.width('100%');
            Stack.height('100%');
        }, Stack);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("tfl/src/main/ets/pages/Index.ets(177:7)", "tfl");
            Column.width('100%');
            Column.height('100%');
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            //时间、boss直聘、两个图标
            Row.create();
            Row.debugLine("tfl/src/main/ets/pages/Index.ets(179:9)", "tfl");
            //时间、boss直聘、两个图标
            Row.linearGradient({
                angle: 60,
                colors: [
                    ['#c36dedef', 0.0],
                    ['#ffeec6b4', 1.0]
                ]
            });
            //时间、boss直聘、两个图标
            Row.width('100%');
            //时间、boss直聘、两个图标
            Row.height(40);
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create("11:04");
            Text.debugLine("tfl/src/main/ets/pages/Index.ets(180:11)", "tfl");
            Text.margin({ right: 55, left: 40 });
            Text.fontWeight(FontWeight.Bold);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create("boss直聘");
            Text.debugLine("tfl/src/main/ets/pages/Index.ets(183:11)", "tfl");
            Text.fontWeight(FontWeight.Bold);
            Text.fontSize(18);
            Text.fontColor('#ff3bae8f');
        }, Text);
        Text.pop();
        //时间、boss直聘、两个图标
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            //鸿蒙开发工程师
            Row.create();
            Row.debugLine("tfl/src/main/ets/pages/Index.ets(199:9)", "tfl");
            //鸿蒙开发工程师
            Row.linearGradient({
                angle: 60,
                colors: [
                    ['#c36dedef', 0.0],
                    ['#ffeec6b4', 1.0]
                ]
            });
            //鸿蒙开发工程师
            Row.width('100%');
            //鸿蒙开发工程师
            Row.height(50);
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('鸿蒙开发工程师');
            Text.debugLine("tfl/src/main/ets/pages/Index.ets(200:11)", "tfl");
            Text.fontWeight(FontWeight.Bold);
            Text.fontSize(24);
            Text.margin({ top: 10, right: 120 });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 50331659, "type": 20000, params: [], "bundleName": "com.0408.myapplication", "moduleName": "tfl" });
            Image.debugLine("tfl/src/main/ets/pages/Index.ets(204:11)", "tfl");
            Image.height(30);
            Image.margin({ right: 10 });
        }, Image);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 50331661, "type": 20000, params: [], "bundleName": "com.0408.myapplication", "moduleName": "tfl" });
            Image.debugLine("tfl/src/main/ets/pages/Index.ets(207:11)", "tfl");
            Image.height(30);
        }, Image);
        //鸿蒙开发工程师
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('推荐职位已更新');
            Text.debugLine("tfl/src/main/ets/pages/Index.ets(220:9)", "tfl");
            Text.fontColor('#ff4593a7');
            Text.margin({ top: 10 });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 标签栏tab+地点+筛选
            Row.create();
            Row.debugLine("tfl/src/main/ets/pages/Index.ets(225:9)", "tfl");
            // 标签栏tab+地点+筛选
            Row.height(21);
            // 标签栏tab+地点+筛选
            Row.justifyContent(FlexAlign.Start);
            // 标签栏tab+地点+筛选
            Row.padding(10);
            // 标签栏tab+地点+筛选
            Row.width('100%');
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 标签栏
            Row.create();
            Row.debugLine("tfl/src/main/ets/pages/Index.ets(227:11)", "tfl");
            // 标签栏
            Row.margin({ right: 20 });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            ForEach.create();
            const forEachItemGenFunction = (_item, index: number) => {
                const tab = _item;
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Text.create(tab);
                    Text.debugLine("tfl/src/main/ets/pages/Index.ets(229:15)", "tfl");
                    Text.fontSize(16);
                    Text.fontColor(this.currentTabIndex === index ? '#000' : '#999');
                    Text.margin({ right: 20 });
                    Text.onClick(() => {
                        this.currentTabIndex = index;
                        this.updateDisplayedJobs(); // 更新显示的职位列表
                    });
                }, Text);
                Text.pop();
            };
            this.forEachUpdateFunction(elmtId, this.tabs, forEachItemGenFunction, undefined, true, false);
        }, ForEach);
        ForEach.pop();
        // 标签栏
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 在"最新"后面添加的按钮
            Button.createWithLabel('北京');
            Button.debugLine("tfl/src/main/ets/pages/Index.ets(242:11)", "tfl");
            // 在"最新"后面添加的按钮
            Button.backgroundColor(Color.White);
            // 在"最新"后面添加的按钮
            Button.fontColor(Color.Gray);
            // 在"最新"后面添加的按钮
            Button.border({
                width: 1,
                color: "#ff756d6d",
                radius: 0
            });
            // 在"最新"后面添加的按钮
            Button.height(20);
            // 在"最新"后面添加的按钮
            Button.width(50);
            // 在"最新"后面添加的按钮
            Button.fontSize(8);
            // 在"最新"后面添加的按钮
            Button.margin({ left: 20 });
        }, Button);
        // 在"最新"后面添加的按钮
        Button.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel('筛选');
            Button.debugLine("tfl/src/main/ets/pages/Index.ets(255:11)", "tfl");
            Button.backgroundColor(Color.White);
            Button.fontColor(Color.Gray);
            Button.border({
                width: 1,
                color: "#ff756d6d",
                radius: 0
            });
            Button.height(20);
            Button.margin({ left: 10 });
            Button.fontSize(8);
        }, Button);
        Button.pop();
        // 标签栏tab+地点+筛选
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 职位列表区域 - 使用Scroll确保内容过多时可滚动
            Scroll.create();
            Scroll.debugLine("tfl/src/main/ets/pages/Index.ets(273:9)", "tfl");
            // 职位列表区域 - 使用Scroll确保内容过多时可滚动
            Scroll.height(540);
            // 职位列表区域 - 使用Scroll确保内容过多时可滚动
            Scroll.width('100%');
        }, Scroll);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("tfl/src/main/ets/pages/Index.ets(274:11)", "tfl");
            Column.width('100%');
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 使用ForEach渲染当前显示的职位列表
            ForEach.create();
            const forEachItemGenFunction = _item => {
                const job = _item;
                this.buildJobCard.bind(this)(job);
            };
            this.forEachUpdateFunction(elmtId, this.displayedJobs, forEachItemGenFunction);
        }, ForEach);
        // 使用ForEach渲染当前显示的职位列表
        ForEach.pop();
        Column.pop();
        // 职位列表区域 - 使用Scroll确保内容过多时可滚动
        Scroll.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            //底部导航
            Row.create();
            Row.debugLine("tfl/src/main/ets/pages/Index.ets(286:9)", "tfl");
            //底部导航
            Row.width('100%');
            //底部导航
            Row.height(20);
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            //职位
            Column.create();
            Column.debugLine("tfl/src/main/ets/pages/Index.ets(288:11)", "tfl");
            //职位
            Column.padding({ left: 40, right: 20 });
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 50331660, "type": 20000, params: [], "bundleName": "com.0408.myapplication", "moduleName": "tfl" });
            Image.debugLine("tfl/src/main/ets/pages/Index.ets(289:13)", "tfl");
            Image.width(50);
            Image.height(40);
        }, Image);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('职位');
            Text.debugLine("tfl/src/main/ets/pages/Index.ets(292:13)", "tfl");
            Text.fontSize(12);
            Text.fontColor('#00A6FF');
        }, Text);
        Text.pop();
        //职位
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            //有了
            Column.create();
            Column.debugLine("tfl/src/main/ets/pages/Index.ets(300:11)", "tfl");
            //有了
            Column.padding({ left: 25, right: 25 });
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Badge.create({
                count: 1,
                position: BadgePosition.Right,
                style: {
                    badgeSize: 8,
                    fontSize: 12,
                    badgeColor: Color.Red
                }
            });
            Badge.debugLine("tfl/src/main/ets/pages/Index.ets(301:13)", "tfl");
        }, Badge);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 50331662, "type": 20000, params: [], "bundleName": "com.0408.myapplication", "moduleName": "tfl" });
            Image.debugLine("tfl/src/main/ets/pages/Index.ets(310:15)", "tfl");
            Image.width(30);
            Image.height(30);
            Image.margin({ top: 5 });
        }, Image);
        Badge.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('有了');
            Text.debugLine("tfl/src/main/ets/pages/Index.ets(316:13)", "tfl");
            Text.fontSize(12);
            Text.fontColor('#ff070707');
            Text.margin({ top: 19 });
        }, Text);
        Text.pop();
        //有了
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            //消息
            Column.create();
            Column.debugLine("tfl/src/main/ets/pages/Index.ets(324:11)", "tfl");
            //消息
            Column.padding({ left: 25, right: 25 });
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Badge.create({
                count: 2,
                position: BadgePosition.Right,
                style: {
                    badgeSize: 8,
                    fontSize: 12,
                    badgeColor: Color.Red
                }
            });
            Badge.debugLine("tfl/src/main/ets/pages/Index.ets(325:13)", "tfl");
        }, Badge);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 50331657, "type": 20000, params: [], "bundleName": "com.0408.myapplication", "moduleName": "tfl" });
            Image.debugLine("tfl/src/main/ets/pages/Index.ets(334:15)", "tfl");
            Image.width(30);
            Image.height(30);
            Image.margin({ top: 5 });
        }, Image);
        Badge.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('消息');
            Text.debugLine("tfl/src/main/ets/pages/Index.ets(340:13)", "tfl");
            Text.fontSize(12);
            Text.fontColor('#ff070707');
            Text.margin({ top: 19 });
        }, Text);
        Text.pop();
        //消息
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            //我的
            Column.create();
            Column.debugLine("tfl/src/main/ets/pages/Index.ets(348:11)", "tfl");
            //我的
            Column.padding({ left: 25, right: 25 });
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Badge.create({
                count: 2,
                position: BadgePosition.Right,
                style: {
                    badgeSize: 8,
                    fontSize: 12,
                    badgeColor: Color.Red
                }
            });
            Badge.debugLine("tfl/src/main/ets/pages/Index.ets(349:13)", "tfl");
        }, Badge);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 50331656, "type": 20000, params: [], "bundleName": "com.0408.myapplication", "moduleName": "tfl" });
            Image.debugLine("tfl/src/main/ets/pages/Index.ets(358:15)", "tfl");
            Image.width(30);
            Image.height(30);
            Image.margin({ top: 2 });
        }, Image);
        Badge.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('我的');
            Text.debugLine("tfl/src/main/ets/pages/Index.ets(364:13)", "tfl");
            Text.fontSize(12);
            Text.fontColor('#ff070707');
            Text.margin({ top: 19 });
        }, Text);
        Text.pop();
        //我的
        Column.pop();
        //底部导航
        Row.pop();
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            // 使用条件渲染显示提示框
            if (this.showDialog) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.customDialog.bind(this)();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                });
            }
        }, If);
        If.pop();
        Stack.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "Index";
    }
}
registerNamedRoute(() => new Index(undefined, {}), "", { bundleName: "com.0408.myapplication", moduleName: "tfl", pagePath: "pages/Index", pageFullPath: "tfl/src/main/ets/pages/Index", integratedHsp: "false", moduleType: "followWithHap" });
